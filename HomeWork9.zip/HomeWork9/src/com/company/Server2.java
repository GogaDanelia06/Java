package com.company;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server2 extends Thread {
    Socket socket;
    ObjectInputStream objectInputStream;
    String message;
    ObjectOutputStream objectOutputStream;

    public Server2() {
    }

    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(8081);

            while(true) {
                do {
                    this.socket = serverSocket.accept();
                    this.objectInputStream = new ObjectInputStream(this.socket.getInputStream());
                    this.message = (String)this.objectInputStream.readObject();
                    this.message = this.getText(this.message);
                    this.objectOutputStream = new ObjectOutputStream(this.socket.getOutputStream());
                    this.objectOutputStream.writeObject(this.message);
                    System.out.println(this.message);
                } while(!this.message.equals("bye"));

                System.out.println("Bye");
                System.exit(0);
            }
        } catch (ClassNotFoundException | IOException var2) {
            var2.printStackTrace();
        }
    }

    public String getText(String command) {
        String line2 = "";

        try {
            File file = new File("info.txt");
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            String line;
            while((line = br.readLine()) != null) {
                if (this.message.equals("error")) {
                    if (line.substring(0, this.message.length() - 1).equals("erro")) {
                        line2 = line.substring(this.message.length() + 3);
                    }
                } else if (line.substring(0, this.message.length()).equals(command)) {
                    line2 = line.substring(this.message.length() + 3);
                }
            }

            fr.close();
        } catch (IOException var7) {
            var7.printStackTrace();
        }

        return line2;
    }
}
