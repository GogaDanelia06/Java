package com.company;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client1 extends Thread {
    Socket socket;
    ObjectOutputStream objectOutputStream;
    String message;
    String message1;
    ObjectInputStream objectInputStream;
    Scanner scanner;
    static String IP;

    public Client1() {
    }

    public void run() {
        try {
            this.scanner = new Scanner(System.in);
            System.out.println("ip:");
            IP = this.scanner.next();

            while(true) {
                do {
                    this.socket = new Socket(InetAddress.getByName(IP), 8080);
                    this.scanner = new Scanner(System.in);
                    System.out.print("Enter Client: ");
                    this.message1 = this.scanner.nextLine();
                    this.objectOutputStream = new ObjectOutputStream(this.socket.getOutputStream());
                    this.objectOutputStream.writeObject(this.message1);
                    this.objectInputStream = new ObjectInputStream(this.socket.getInputStream());
                    this.message = (String)this.objectInputStream.readObject();
                    System.out.println("===Client===");
                    System.out.println("Server:" + this.message);
                    System.out.println(this.message1);
                } while(!this.message1.equals("bye"));

                System.out.println(this.message1);
                System.exit(0);
            }
        } catch (ClassNotFoundException | IOException var2) {
            var2.printStackTrace();
        }
    }
}
