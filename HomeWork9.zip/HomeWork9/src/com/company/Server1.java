package com.company;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server1 extends Thread {
    Socket socket;
    ObjectInputStream objectInputStream;
    String message;
    ObjectOutputStream objectOutputStream;

    public Server1() {
    }

    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(1234);

            while(true) {
                do {
                    this.socket = serverSocket.accept();
                    this.objectInputStream = new ObjectInputStream(this.socket.getInputStream());
                    this.message = (String)this.objectInputStream.readObject();
                    Scanner scanner = new Scanner(System.in);
                    System.out.print("Server enter:");
                    this.message = scanner.nextLine();
                    this.objectOutputStream = new ObjectOutputStream(this.socket.getOutputStream());
                    this.objectOutputStream.writeObject(this.message);
                } while(!this.message.equals("bye"));

                System.out.println("Bye");
                System.exit(0);
            }
        } catch (ClassNotFoundException | IOException var3) {
            var3.printStackTrace();
        }
    }
}
