package com.company;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
//        Client2 client2 = new Client2();
//        Server2 server2 = new Server2();
//        client2.start();
//        server2.start();
        Client1 client1 = new Client1();
        Server1 server1 = new Server1();
        client1.start();
        server1.start();
    }
}
