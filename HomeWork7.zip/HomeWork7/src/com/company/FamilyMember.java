package com.company;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//



import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class FamilyMember {
    private String name;
    private String lastName;
    private String status;
    private int age;
    protected String addr = "src/gau/Works/FamilyData";

    public FamilyMember(String name, String lastName, int age, String status) {
        this.name = name;
        this.lastName = lastName;
        this.age = age;
        this.status = status;
        this.saveFamily();
    }

    public void saveFamily() {
        this.creteFolder();

        try {
            FileWriter wrt = new FileWriter(this.addr + "/family.txt");
            new Date();
            wrt.write("Name: " + this.name + "\nLastName: " + this.lastName + "\nAge: " + this.age + "\nStatus: " + this.status);
            wrt.close();
        } catch (IOException var3) {
            var3.printStackTrace();
        }

    }

    public void creteFolder() {
        File directory = new File(this.addr);
        if (!directory.exists()) {
            directory.mkdir();
        }

    }
}
