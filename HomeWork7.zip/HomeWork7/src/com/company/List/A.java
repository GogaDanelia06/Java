package com.company.List;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class A implements InterfaceForA {
    protected ArrayList<Integer> arr = new ArrayList();
    protected ArrayList<String> arrs = new ArrayList();

    public A() {
    }

    public void fillListWith5() {
        this.arr.clear();

        for(int i = 0; i < 5; ++i) {
            this.arr.add((int)(Math.random() * 101.0D));
        }

    }

    public void fillListWith20() {
        this.arr.clear();

        for(int i = 0; i < 20; ++i) {
            this.arr.add((int)(Math.random() * 101.0D));
        }

    }

    public void fillListWith20s() {
        this.arrs.clear();

        for(int i = 0; i < 20; ++i) {
            this.arrs.add(this.randWord());
        }

    }

    public void printList() {
        for(int i = 0; i < this.arr.size(); ++i) {
            if (i == this.arr.size() - 1) {
                System.out.println(this.arr.get(i));
            } else {
                PrintStream var10000 = System.out;
                Object var10001 = this.arr.get(i);
                var10000.print(var10001 + ", ");
            }
        }

    }

    public void printList(ArrayList<?> array) {
        for(int i = 0; i < array.size(); ++i) {
            if (i == array.size() - 1) {
                System.out.println(array.get(i));
            } else {
                PrintStream var10000 = System.out;
                Object var10001 = array.get(i);
                var10000.print(var10001 + ", ");
            }
        }

    }

    public void sortASC() {
        Collections.sort(this.arr);
    }

    public void sortDESC() {
        Collections.sort(this.arr);
        Collections.reverse(this.arr);
    }

    public String randWord() {
        StringBuilder word = new StringBuilder();
        Random r = new Random();

        for(int i = 0; i < 10; ++i) {
            word.append((char)(r.nextInt(26) + 97));
        }

        return word.toString();
    }
}

