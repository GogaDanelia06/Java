package com.company.List;

import java.util.ArrayList;
import java.util.ArrayList;

public interface InterfaceForA {
    void fillListWith5();

    void fillListWith20();

    void fillListWith20s();

    void printList();

    void printList(ArrayList<?> var1);

    void sortASC();

    void sortDESC();

    String randWord();
}
