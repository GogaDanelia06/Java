package com.company;

public class Main {

    public static void main(String[] args) {
        new Works1_16();
        FamilyBudget fb = new FamilyBudget();
        fb.setMoney(12000);
        new FamilyMember("Goga", "Danelia", 21, "Student");
    }
}

    }
}
