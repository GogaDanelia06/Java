package com.company;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class FamilyBudget {
    private int money;
    protected String addr = "src/gau/Works/FamilyData";

    public FamilyBudget() {
    }

    public void setMoney(int money) {
        this.money = money;
        this.saveBudgetState();
    }

    public int getMoney() {
        return this.money;
    }

    public String determineBudgetState() {
        if (this.money > 40000) {
            return "Rich";
        } else {
            return this.money > 10000 ? "Medium" : "Poor";
        }
    }

    public void saveBudgetState() {
        this.creteFolder();

        try {
            FileWriter wrt = new FileWriter(this.addr + "/budget.txt");
            Date date = new Date();
            String var10001 = date.toString();
            wrt.write(var10001 + "--> " + this.determineBudgetState());
            wrt.close();
        } catch (IOException var3) {
            var3.printStackTrace();
        }

    }

    public void creteFolder() {
        File directory = new File(this.addr);
        if (!directory.exists()) directory.mkdir();

    }
}

}
