package sample;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Optional;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

public class Controller {
    private String dburl = "jdbc:mysql://localhost:3306/realestate";
    private static Integer selectedId;
    @FXML
    private BorderPane mainPane;
    @FXML
    protected Button editBTN;
    @FXML
    protected Button deleteBTN;

    public Controller() {
    }

    public void setSelectedId(Integer selectedId) {
        Controller.selectedId = selectedId;
    }

    public Integer getSelectedId() {
        return selectedId;
    }

    @FXML
    public void add() {
        FXMLLoader loader = new FXMLLoader(this.getClass().getResource("save.fxml"));
        Pane root = null;

        try {
            root = (Pane)loader.load();
        } catch (IOException var4) {
            var4.printStackTrace();
        }

        this.mainPane.setCenter(root);
    }

    @FXML
    public void view() {
        try {
            FXMLLoader loader = new FXMLLoader(this.getClass().getResource("view.fxml"));
            Pane root = (Pane)loader.load();
            this.mainPane.setCenter(root);
            ViewController controller = (ViewController)loader.getController();
            controller.getData();
        } catch (IOException var4) {
            var4.printStackTrace();
        }

    }

    @FXML
    public void edit() {
        try {
            FXMLLoader loader = new FXMLLoader(this.getClass().getResource("save.fxml"));
            Pane root = (Pane)loader.load();
            this.mainPane.setCenter(root);
            SaveController controller = (SaveController)loader.getController();
            controller.update();
        } catch (IOException var4) {
            var4.printStackTrace();
        }

    }

    @FXML
    public void delete() {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("DeleteConfirmation");
        alert.setHeaderText("Are you sure?");
        alert.setContentText("Delete can not be undone.");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            try {
                if (selectedId != null) {
                    Connection con = DriverManager.getConnection(this.dburl, "root", "");
                    String query = "delete from estate where id=?";
                    PreparedStatement st = con.prepareStatement(query);
                    st.setInt(1, selectedId);
                    st.executeUpdate();
                    st.close();
                    Alert a = new Alert(AlertType.INFORMATION, "Success!", new ButtonType[0]);
                    a.show();
                } else {
                    Alert a = new Alert(AlertType.WARNING, "Please Select Data in View", new ButtonType[0]);
                    a.show();
                }
            } catch (SQLException var7) {
                var7.printStackTrace();
            }
        }

    }
}
