package sample;


import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ViewController extends Controller implements Initializable {
    private String dburl = "jdbc:mysql://localhost:3306/realestate";
    private Integer selectedId = null;
    @FXML
    private TableView<Estate> viewTable = new TableView();

    public ViewController() {
    }

    @FXML
    public void getData() {
        try {
            Connection con = DriverManager.getConnection(this.dburl, "root", "");
            String query = "select * from estate";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            ObservableList dbData = FXCollections.observableArrayList(this.dataBaseArrayList(rs));

            for(int i = 0; i < rs.getMetaData().getColumnCount(); ++i) {
                TableColumn column = new TableColumn();
                String var8 = rs.getMetaData().getColumnName(i + 1);
                byte var9 = -1;
                switch(var8.hashCode()) {
                    case -1724546052:
                        if (var8.equals("description")) {
                            var9 = 9;
                        }
                        break;
                    case -1068855134:
                        if (var8.equals("mobile")) {
                            var9 = 8;
                        }
                        break;
                    case -891990013:
                        if (var8.equals("street")) {
                            var9 = 3;
                        }
                        break;
                    case 3355:
                        if (var8.equals("id")) {
                            var9 = 0;
                        }
                        break;
                    case 3575610:
                        if (var8.equals("type")) {
                            var9 = 4;
                        }
                        break;
                    case 96619420:
                        if (var8.equals("email")) {
                            var9 = 7;
                        }
                        break;
                    case 106934601:
                        if (var8.equals("price")) {
                            var9 = 6;
                        }
                        break;
                    case 108698360:
                        if (var8.equals("rooms")) {
                            var9 = 5;
                        }
                        break;
                    case 957831062:
                        if (var8.equals("country")) {
                            var9 = 2;
                        }
                        break;
                    case 1197595052:
                        if (var8.equals("sellType")) {
                            var9 = 1;
                        }
                }

                switch(var9) {
                    case 0:
                        column.setText("ID");
                        break;
                    case 1:
                        column.setText("გარიგების ტიპი");
                        break;
                    case 2:
                        column.setText("მდებარეობა");
                        break;
                    case 3:
                        column.setText("უბანი");
                        break;
                    case 4:
                        column.setText("ქონების ტიპი");
                        break;
                    case 5:
                        column.setText("ოთახების რაოდენობა");
                        break;
                    case 6:
                        column.setText("ფასი");
                        break;
                    case 7:
                        column.setText("ელ-ფოსტა");
                        break;
                    case 8:
                        column.setText("მობილური");
                        break;
                    case 9:
                        column.setText("განცხადების ტექსტი");
                        break;
                    default:
                        column.setText(rs.getMetaData().getColumnName(i + 1));
                }

                column.setCellValueFactory(new PropertyValueFactory(rs.getMetaData().getColumnName(i + 1)));
                this.viewTable.getColumns().add(column);
            }

            this.viewTable.setItems(dbData);
        } catch (SQLException var10) {
            var10.printStackTrace();
        }

    }

    private ArrayList dataBaseArrayList(ResultSet resultSet) throws SQLException {
        ArrayList data = new ArrayList();

        while(resultSet.next()) {
            Estate estate = new Estate();
            estate.id.set(resultSet.getInt("id"));
            estate.sellType.set(resultSet.getString("sellType"));
            estate.country.set(resultSet.getString("country"));
            estate.street.set(resultSet.getString("street"));
            estate.type.set(resultSet.getString("type"));
            estate.rooms.set(resultSet.getFloat("rooms"));
            estate.price.set(resultSet.getString("price"));
            estate.email.set(resultSet.getBoolean("email"));
            estate.mobile.set(resultSet.getBoolean("mobile"));
            estate.description.set(resultSet.getString("description"));
            data.add(estate);
        }

        return data;
    }

    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.setSelectedId(this.selectedId);
        this.viewTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null) {
                this.selectedId = null;
            } else {
                this.selectedId = newValue.id.get();
                this.setSelectedId(this.selectedId);
            }
        });
    }
}
