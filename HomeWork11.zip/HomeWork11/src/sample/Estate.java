package sample;


import javafx.beans.property.BooleanProperty;
import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Estate {
    IntegerProperty id = new SimpleIntegerProperty();
    StringProperty sellType = new SimpleStringProperty();
    StringProperty country = new SimpleStringProperty();
    StringProperty street = new SimpleStringProperty();
    StringProperty type = new SimpleStringProperty();
    FloatProperty rooms = new SimpleFloatProperty();
    StringProperty price = new SimpleStringProperty();
    BooleanProperty email = new SimpleBooleanProperty();
    BooleanProperty mobile = new SimpleBooleanProperty();
    StringProperty description = new SimpleStringProperty();

    public IntegerProperty idProperty() {
        return this.id;
    }

    public StringProperty sellTypeProperty() {
        return this.sellType;
    }

    public StringProperty countryProperty() {
        return this.country;
    }

    public StringProperty streetProperty() {
        return this.street;
    }

    public StringProperty typeProperty() {
        return this.type;
    }

    public FloatProperty roomsProperty() {
        return this.rooms;
    }

    public StringProperty priceProperty() {
        return this.price;
    }

    public BooleanProperty emailProperty() {
        return this.email;
    }

    public BooleanProperty mobileProperty() {
        return this.mobile;
    }

    public StringProperty descriptionProperty() {
        return this.description;
    }

    public Estate(int idValue, String sellTypeValue, String countryValue, String streetValue, String typeValue, float roomsValue, String priceValue, boolean emailValue, boolean mobileValue, String descValue) {
        this.id.set(idValue);
        this.sellType.set(sellTypeValue);
        this.country.set(countryValue);
        this.street.set(streetValue);
        this.type.set(typeValue);
        this.rooms.set(roomsValue);
        this.price.set(priceValue);
        this.email.set(emailValue);
        this.mobile.set(mobileValue);
        this.description.set(descValue);
    }

    Estate() {
    }
}
