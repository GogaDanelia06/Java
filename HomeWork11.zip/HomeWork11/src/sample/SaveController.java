package sample;


import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;

public class SaveController extends Controller implements Initializable {
    private String dburl = "jdbc:mysql://localhost:3306/realestate";
    private Integer selectedId = null;
    @FXML
    private ComboBox<String> selltype;
    @FXML
    private ComboBox<String> country;
    @FXML
    private ComboBox<String> street;
    @FXML
    private ComboBox<String> type;
    @FXML
    private ComboBox<String> priceformat;
    @FXML
    private ToggleGroup room;
    @FXML
    private TextField price;
    @FXML
    private CheckBox email;
    @FXML
    private CheckBox mobile;
    @FXML
    private TextArea text;

    public SaveController() {
    }

    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.selectedId = this.getSelectedId();
        this.selltype.getItems().addAll(new String[]{"იყიდება", "ქირავდება"});
        this.selltype.getSelectionModel().select(0);
        this.country.getItems().addAll(new String[]{"თბილისი", "ქუთაისი", "ბათუმი"});
        this.country.getSelectionModel().select(0);
        this.street.getItems().addAll(new String[]{"საბურთალო", "ვარკეთილი", "გლდანი"});
        this.street.getSelectionModel().select(0);
        this.type.getItems().addAll(new String[]{"ბინა", "გარაჟი"});
        this.type.getSelectionModel().select(0);
        this.priceformat.getItems().addAll(new String[]{"დოლარი", "ლარი"});
        this.priceformat.getSelectionModel().select(0);
    }

    @FXML
    public void save() {
        try {
            RadioButton selectedRadioButton = (RadioButton)this.room.getSelectedToggle();
            Connection con = DriverManager.getConnection(this.dburl, "root", "");
            String query;
            PreparedStatement st;
            if (this.selectedId != null) {
                query = "UPDATE estate SET sellType = ?, country = ?, street = ?, type = ?, rooms = ?, price = ?, email = ?, mobile = ?, description = ? WHERE id = ?";
                st = con.prepareStatement(query);
                st.setInt(10, this.selectedId);
            } else {
                query = "INSERT INTO estate (sellType, country, street, type, rooms, price, email, mobile, description) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
                st = con.prepareStatement(query);
            }

            st.setString(1, (String)this.selltype.getValue());
            st.setString(2, (String)this.country.getValue());
            st.setString(3, (String)this.street.getValue());
            st.setString(4, (String)this.type.getValue());
            st.setFloat(5, Float.parseFloat(selectedRadioButton.getText()));
            String var10002 = this.price.getText();
            st.setString(6, var10002 + " " + (String)this.priceformat.getValue());
            st.setBoolean(7, this.email.isSelected());
            st.setBoolean(8, this.mobile.isSelected());
            st.setString(9, this.text.getText());
            st.executeUpdate();
            st.close();
            Alert a = new Alert(AlertType.INFORMATION, "Success!", new ButtonType[0]);
            a.show();
        } catch (SQLException var6) {
            var6.printStackTrace();
        }

    }

    public void update() {
        if (this.selectedId != null) {
            this.fillForm();
        } else {
            Alert a = new Alert(AlertType.WARNING);
            a.setHeaderText("Please Select Data in View");
            a.show();
        }

    }

    public void fillForm() {
        try {
            Connection con = DriverManager.getConnection(this.dburl, "root", "");
            String query = "select * from estate where id=" + this.selectedId;
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            rs.next();
            this.selltype.getSelectionModel().select(rs.getString("sellType"));
            this.country.getSelectionModel().select(rs.getString("country"));
            this.street.getSelectionModel().select(rs.getString("street"));
            this.type.getSelectionModel().select(rs.getString("type"));
            int selectedToggleIndex = this.room.getToggles().indexOf(String.valueOf(rs.getFloat("rooms")));
            this.price.setText(rs.getString("price").replaceAll("\\D+", ""));
            this.priceformat.getSelectionModel().select(rs.getString("price").replaceAll("[0-9]", ""));
            this.email.setSelected(rs.getBoolean("email"));
            this.mobile.setSelected(rs.getBoolean("mobile"));
            this.text.setText(rs.getString("description"));
        } catch (SQLException var6) {
            var6.printStackTrace();
        }

    }
}
